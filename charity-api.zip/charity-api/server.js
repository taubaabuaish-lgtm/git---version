import express from 'express';
import apicAgentRoutes from './routes/apicAgent.routes.js';
import charityRoutes from './routes/charity.routes.js';
import logger from './utils/logger.js';  

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

app.use('/api/apicagent', apicAgentRoutes);
app.use('/api/charity', charityRoutes);

app.listen(PORT, () => {
  logger.info(`Server running at  :  ${PORT}`);
});
