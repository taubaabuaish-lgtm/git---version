import axios from 'axios';

const API_URL = 'https://api.apicagent.com';

export async function getDeviceDetails(userAgent) {
  try {
    const response = await axios.get(API_URL, {
      params: { ua: userAgent }
    });
    return response.data;
  } catch (error) {
    throw new Error('Failed to fetch device details');
  }
}
