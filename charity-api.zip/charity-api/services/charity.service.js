import axios from 'axios';

const API_BASE_URL = 'https://api.charityapi.com/v1';

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

export async function getCharityByEIN(ein) {
  try {
    const response = await apiClient.get(`/organizations/${ein}`);
    return response.data;
  } catch (error) {
    throw error;
  }
}

export async function searchCharities({ name, city, state }) {
  try {
    const params = {};
    if (name) params.name = name;
    if (city) params.city = city;
    if (state) params.state = state;

    const response = await apiClient.get('/organizations/search', { params });
    return response.data;
  } catch (error) {
    throw error;
  }
}
