import express from 'express';
import { detectDevice } from '../controllers/apicAgent.controller.js';

const router = express.Router();

router.get('/detect', detectDevice);

export default router;
