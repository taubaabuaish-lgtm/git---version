import express from 'express';
import { getCharity, searchCharities } from '../controllers/charity.controller.js';

const router = express.Router();

router.get('/:ein', getCharity);
router.get('/search', searchCharities);

export default router;
