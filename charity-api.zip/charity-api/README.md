
# פרויקט API עם Express ו-Routers מרובים

# ---------  תיאור הפרויקט
פרויקט זה הוא API בשרת Node.js באמצעות Express, המפצל את הקוד למספר רכיבים (Routes, Controllers, Services) ומאפשר שימוש ביותר מרוטר אחד לניהול מסלולים שונים.

# ---------  מבנה הפרויקט
- **server.js** - קובץ הכניסה הראשי, מגדיר את השרת ומקשר בין הרוטר השונים לנתיבים הראשיים.
- **routes/** - מכיל קבצי רוטר שונים (למשל `apicAgent.routes.js` ו-`charity.routes.js`), כל אחד מטפל בקבוצה שונה של נתיבים.
- **controllers/** - מכיל את הלוגיקה לטיפול בבקשות המגיעות מרוטר מסוים.
- **services/** - מכיל פונקציות אשר מבצעות את הקריאות ל-API חיצוני או טיפול בנתונים.

# -------  טכנולוגיות
- Node.js
- Express (גרסה 5)
- Axios
- ניהול רוטרים נפרדים

# ----- איך להריץ את הפרויקט
1. להתקין את התלויות:
npm install

להפעיל את השרת:
npm start

השרת יפעל בכתובת:

http://localhost:3000
דוגמאות לקריאות API
APIC Agent - לזהות מידע על מכשיר:

GET /api/apicagent/detect
Charity API - לקבל מידע על ארגון לפי EIN:

GET /api/charity/:ein
Charity API - חיפוש ארגונים לפי שם, עיר או מדינה:

GET /api/charity/search?name=שם&city=עיר&state=מדינה



הערות
הפרויקט משתמש ב-type: "module" ב-package.json ולכן משתמש בתחביר import/export.


