import { getDeviceDetails } from '../services/apicAgent.service.js';

export async function detectDevice(req, res) {
  try {
    const userAgent = req.get('User-Agent') || '';
    const deviceInfo = await getDeviceDetails(userAgent);
    res.json(deviceInfo);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}
