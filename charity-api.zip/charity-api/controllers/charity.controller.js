import { getCharityByEIN, searchCharities as searchCharitiesService } from '../services/charity.service.js';

export async function getCharity(req, res) {
  try {
    const { ein } = req.params;
    const charity = await getCharityByEIN(ein);
    if (!charity) return res.status(404).json({ message: 'Charity not found' });
    res.json(charity);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

export async function searchCharities(req, res) {
  try {
    const { name, city, state } = req.query;
    const charities = await searchCharitiesService({ name, city, state });
    res.json(charities);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}
